cd /Source/Udaan_Main_Trunk
svn --username=kgajare --password=wine@28071986* cleanup



