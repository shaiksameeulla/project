cd /Source/Udaan_Main_Trunk/udaan-framework
mvn  sonar:sonar

cd /Source/Udaan_Main_Trunk/udaan-transfer-object
mvn  sonar:sonar

cd /Source/Udaan_Main_Trunk/udaan-domain
mvn  sonar:sonar

cd /Source/Udaan_Main_Trunk/udaan-universal-routine
mvn  sonar:sonar

cd /Source/Udaan_Main_Trunk/udaan-login
mvn  sonar:sonar

cd /Source/Udaan_Main_Trunk/udaan-rate-calculation
mvn  sonar:sonar

cd /Source/Udaan_Main_Trunk/udaan-terminal
mvn  sonar:sonar

cd /Source/Udaan_Main_Trunk/bcun-data-sync
mvn  sonar:sonar

cd /Source/Udaan_Main_Trunk/udaan-web
mvn  sonar:sonar

cd /Source/Udaan_Main_Trunk/udaan-config-admin
mvn  sonar:sonar

cd /Source/Udaan_Main_Trunk/udaan-central-server
mvn  sonar:sonar

cd /Source/Udaan_Main_Trunk/udaan-report
mvn  sonar:sonar

cd /Source/Udaan_Main_Trunk/udaan-sap-integration-consumer
mvn  sonar:sonar

cd /Source/Udaan_Main_Trunk/udaan-sap-integration
mvn  sonar:sonar

cd /Source/Udaan_Main_Trunk/bcun-asynch-queue-consumer
mvn  sonar:sonar

cd /Source/Udaan_Main_Trunk/udaan-opsman-integration
mvn  sonar:sonar