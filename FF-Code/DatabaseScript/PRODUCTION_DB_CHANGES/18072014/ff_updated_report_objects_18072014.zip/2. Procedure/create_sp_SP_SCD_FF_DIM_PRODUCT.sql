DROP PROCEDURE IF EXISTS sp_scd_ff_dim_product;
CREATE PROCEDURE sp_scd_ff_dim_product()
BEGIN
	
-- Update existing records
UPDATE ff_dim_product dp_t,                             
(SELECT p.PRODUCT_ID,
         p.PRODUCT_CODE,
         p.PRODUCT_NAME,
         p.PRODUCT_DESC,
         p.CONSG_SERIES,
         p.PRODUCT_CLASSIFICATION,
         p.CONSOLIDATION_WINDOW,
         pcm.RATE_PROD_PROD_CAT_MAP_ID,
         pc.RATE_PRODUCT_CATEGORY_ID,
         pc.PRODUCT_CATEGORY_CODE,
         pc.PRODUCT_CATEGORY_NAME,
         pc.RATE_PRODUCT_CATEGORY_TYPE,
         pc.CALCULATION_TYPE,
         pc.DISTRIBUTION_CHANNEL,
         pg.PROD_GROUP_ID,
         pg.PROD_GROUP_CODE,
         pg.PROD_GROUP_NAME
         from ff_d_product p
    join ff_d_rate_prod_prod_cat_map pcm on p.PRODUCT_ID=pcm.product
    join ff_d_rate_product_category pc on pc.rate_product_category_id=pcm.rate_product_category
    join ff_d_product_group_srvcblty pg on p.prod_group_id=pg.prod_group_id) dp_s
    SET   dp_t.PRODUCT_NAME = dp_s.PRODUCT_NAME
        , dp_t.PRODUCT_DESC = dp_s.PRODUCT_DESC
        , dp_t.CONSG_SERIES = dp_s.CONSG_SERIES
        , dp_t.PRODUCT_CLASSIFICATION = dp_s.PRODUCT_CLASSIFICATION
        , dp_t.CONSOLIDATION_WINDOW = dp_s.CONSOLIDATION_WINDOW
        , dp_t.RATE_PROD_PROD_CAT_MAP_ID = dp_s.RATE_PROD_PROD_CAT_MAP_ID
        , dp_t.RATE_PRODUCT_CATEGORY_ID = dp_s.RATE_PRODUCT_CATEGORY_ID
        , dp_t.PRODUCT_CATEGORY_CODE = dp_s.PRODUCT_CATEGORY_CODE
        , dp_t.PRODUCT_CATEGORY_NAME = dp_s.PRODUCT_CATEGORY_NAME
        , dp_t.RATE_PRODUCT_CATEGORY_TYPE = dp_s.RATE_PRODUCT_CATEGORY_TYPE
        , dp_t.CALCULATION_TYPE = dp_s.CALCULATION_TYPE
        , dp_t.DISTRIBUTION_CHANNEL = dp_s.DISTRIBUTION_CHANNEL
        , dp_t.PROD_GROUP_ID = dp_s.PROD_GROUP_ID
        , dp_t.PROD_GROUP_CODE = dp_s.PROD_GROUP_CODE
        , dp_t.PROD_GROUP_NAME = dp_s.PROD_GROUP_NAME
        , LAST_UPDT_DATE=NOW()
    WHERE dp_t.PRODUCT_CODE = dp_s.PRODUCT_CODE ;
commit;     

-- Update existing records
insert into ff_dim_product
select X.* from
(select fn_seq_gen('n_prod_skey') AS N_PROD_SKEY,
       p.PRODUCT_ID,
       p.PRODUCT_CODE,
       p.PRODUCT_NAME,
       p.PRODUCT_DESC,
       p.CONSG_SERIES,
       p.PRODUCT_CLASSIFICATION,
       p.CONSOLIDATION_WINDOW,
       pcm.RATE_PROD_PROD_CAT_MAP_ID,
       pc.RATE_PRODUCT_CATEGORY_ID,
       pc.PRODUCT_CATEGORY_CODE,
       pc.PRODUCT_CATEGORY_NAME,
       pc.RATE_PRODUCT_CATEGORY_TYPE,
       pc.CALCULATION_TYPE,
       pc.DISTRIBUTION_CHANNEL,
       pg.PROD_GROUP_ID,
       pg.PROD_GROUP_CODE,
       pg.PROD_GROUP_NAME,
       CURRENT_DATE as LAST_UPDT_DATE
       from ff_d_product p
join ff_d_rate_prod_prod_cat_map pcm on p.PRODUCT_ID=pcm.product
join ff_d_rate_product_category pc on pc.rate_product_category_id=pcm.rate_product_category
join ff_d_product_group_srvcblty pg on p.prod_group_id=pg.prod_group_id) X,
(select a.PRODUCT_CODE
from ff_d_product a 
left outer join ff_dim_product b on a.PRODUCT_CODE = b.PRODUCT_CODE
where b.PRODUCT_CODE is null and  a.PRODUCT_CODE is not null) Y
where X.PRODUCT_CODE=Y.PRODUCT_CODE;
commit;

END;
