DROP PROCEDURE IF EXISTS sp_scd_ff_dim_geography;
CREATE PROCEDURE sp_scd_ff_dim_geography()
BEGIN

-- Update existing records
UPDATE ff_dim_geography dg_t,                             
    (select   o.OFFICE_ID
            , o.OFFICE_CODE
            , o.OFFICE_NAME
            ,	o.REPORTING_RHO
            ,	o.REPORTING_HUB
            ,	o.PINCODE
            ,	ot.OFFICE_TYPE_ID
            ,	ot.OFFICE_TYPE_CODE
            ,	ot.OFFICE_TYPE_DESC
            ,	c.CITY_ID
            ,	c.CITY_CODE
            ,	c.CITY_NAME
            ,	s.STATE_ID
            ,	s.STATE_CODE
            ,	s.STATE_NAME
            ,	r.REGION_ID
            ,	r.REGION_CODE
            , r.REGION_NAME
            ,	z.ZONE_ID
            ,	z.ZONE_CODE
            ,	z.ZONE_NAME
        from ff_d_office o
        join ff_d_office_type ot on ot.office_type_id=o.office_type_id
        join ff_d_city c on c.city_id=o.city_id
        join ff_d_state s on c.state=s.state_id
        join ff_d_region r on c.region=r.region_id
        join ff_d_zone z on r.zone=z.zone_id) dg_s
    SET dg_t.OFFICE_ID = dg_s.OFFICE_ID
        , dg_t.OFFICE_NAME = dg_s.OFFICE_NAME
        , dg_t.REPORTING_RHO = dg_s.REPORTING_RHO
        , dg_t.REPORTING_HUB = dg_s.REPORTING_HUB
        , dg_t.PINCODE = dg_s.PINCODE
        , dg_t.OFFICE_TYPE_ID = dg_s.OFFICE_TYPE_ID
        , dg_t.OFFICE_TYPE_CODE = dg_s.OFFICE_TYPE_CODE
        , dg_t.OFFICE_TYPE_DESC = dg_s.OFFICE_TYPE_DESC
        , dg_t.CITY_ID = dg_s.CITY_ID
        , dg_t.CITY_CODE = dg_s.CITY_CODE
        , dg_t.CITY_NAME = dg_s.CITY_NAME
        , dg_t.STATE_ID = dg_s.STATE_ID
        , dg_t.STATE_CODE = dg_s.STATE_CODE
        , dg_t.STATE_NAME = dg_s.STATE_NAME
        , dg_t.REGION_ID = dg_s.REGION_ID
        , dg_t.REGION_CODE = dg_s.REGION_CODE
        , dg_t.REGION_NAME = dg_s.REGION_NAME
        , dg_t.ZONE_ID = dg_s.ZONE_ID
        , dg_t.ZONE_CODE = dg_s.ZONE_CODE
        , dg_t.ZONE_NAME = dg_s.ZONE_NAME
        , LAST_UPDT_DATE=NOW()
    WHERE dg_t.OFFICE_ID = dg_s.OFFICE_ID ;
commit;     

-- Inset new records
insert into ff_dim_geography
select X.* from
(select fn_seq_gen('n_geo_skey') AS N_GEO_SKEY 
        , o.OFFICE_ID
        , o.OFFICE_CODE
        , o.OFFICE_NAME
        ,	o.REPORTING_RHO
        ,	o.REPORTING_HUB
        ,	o.PINCODE
        ,	ot.OFFICE_TYPE_ID
        ,	ot.OFFICE_TYPE_CODE
        ,	ot.OFFICE_TYPE_DESC
        ,	c.CITY_ID
        ,	c.CITY_CODE
        ,	c.CITY_NAME
        ,	s.STATE_ID
        ,	s.STATE_CODE
        ,	s.STATE_NAME
        ,	r.REGION_ID
        ,	r.REGION_CODE
        , r.REGION_NAME
        ,	z.ZONE_ID
        ,	z.ZONE_CODE
        ,	z.ZONE_NAME
        , NOW() as LAST_UPDT_DATE
from ff_d_office o
join ff_d_office_type ot on ot.office_type_id=o.office_type_id
join ff_d_city c on c.city_id=o.city_id
join ff_d_state s on c.state=s.state_id
join ff_d_region r on c.region=r.region_id
join ff_d_zone z on r.zone=z.zone_id) X, 
(select a.OFFICE_CODE
from ff_d_office a 
left outer join ff_dim_geography b on a.OFFICE_CODE = b.OFFICE_CODE 
where b.OFFICE_CODE is null and  a.OFFICE_CODE is not null) Y
where X.OFFICE_CODE=Y.OFFICE_CODE;
commit;

END;
