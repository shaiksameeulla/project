DROP PROCEDURE IF EXISTS sp_scd_ff_dim_customer;
CREATE PROCEDURE sp_scd_ff_dim_customer()
BEGIN

-- Update existing records
UPDATE ff_dim_customer dc_t,                             
(select 
       c.created_date as cust_created_date,
	  c.updated_date as cust_updated_date,
	  c.CUSTOMER_ID,
       c.CONTRACT_NO,
       c.CUSTOMER_CODE,
       o.OFFICE_CODE AS SALES_OFFICE_CODE,
       o.office_name AS SALES_OFFICE,
       concat(e.first_name,' ',e.last_name) AS SALES_PERSON,
       ic.industry_category_name AS INDUSTRY_CATEGORY,
       it.industry_type_name AS INDUSTRY_TYPE,
       c.DISTRIBUTION_CHANNELS,
       c.BUSINESS_NAME,
       c.ADDRESS,
       c.PRIMARY_CONTACT,
       c.SECONDARY_CONTACT,
       c.BILLING_CYCLE,
       c.PAYEMENT_TERM,
       c.OFFICE_MAPPED_TO,
       c.TAN_NO,
       c.PAN_NO,
       c.CUR_STATUS,
       c.BUSINESS_TYPE,
       c.SAP_TIMESTAMP,
       c.PHONE,
       c.MOBILE,
       c.EMAIL,
       c.LEGACY_CUSTOMER_CODE,
       cc.RATE_CUSTOMER_CATEGORY_ID,
       cc.CUSTOMER_CATEGORY_CODE,
       cc.CUSTOMER_CATEGORY_NAME,
       ct.CUSTOMER_TYPE_ID,
       ct.CUSTOMER_TYPE_CODE,
       ct.CUSTOMER_TYPE_DESC,
       cg.CUSTOMER_GROUP_ID,
       cg.CUSTOMER_GROUP_CODE,
       cg.CUSTOMER_GROUP_NAME
  FROM ff_d_customer c
       LEFT JOIN ff_d_rate_customer_category cc
          ON c.customer_category = cc.rate_customer_category_id
       LEFT JOIN ff_d_customer_type ct
          ON c.customer_type = ct.customer_type_id
       LEFT JOIN ff_d_customer_group cg
          ON c.group_key = cg.customer_group_id
       LEFT JOIN ff_d_employee e
          ON e.EMPLOYEE_ID = c.SALES_PERSON
       LEFT JOIN ff_d_office o
          ON o.office_id = c.SALES_OFFICE
       LEFT JOIN ff_d_office o1
          ON o1.office_id = c.OFFICE_MAPPED_TO
       LEFT JOIN ff_d_rate_industry_category ic
          ON c.INDUSTRY_CATEGORY = ic.RATE_INDUSTRY_CATEGORY_ID
       LEFT JOIN ff_d_rate_industry_type it
          ON c.INDUSTRY_TYPE = it.rate_industry_type_id) dc_s
    SET dc_t.CONTRACT_NO = dc_s.CONTRACT_NO
        ,dc_t.CUSTOMER_ID = dc_s.CUSTOMER_ID
        ,dc_t.SALES_OFFICE_CODE = dc_s.SALES_OFFICE_CODE
        ,dc_t.SALES_OFFICE = dc_s.SALES_OFFICE
        ,dc_t.SALES_PERSON = dc_s.SALES_PERSON
        ,dc_t.INDUSTRY_CATEGORY = dc_s.INDUSTRY_CATEGORY
        ,dc_t.INDUSTRY_TYPE = dc_s.INDUSTRY_TYPE
        ,dc_t.DISTRIBUTION_CHANNELS = dc_s.DISTRIBUTION_CHANNELS
        ,dc_t.BUSINESS_NAME = dc_s.BUSINESS_NAME
        ,dc_t.ADDRESS = dc_s.ADDRESS
        ,dc_t.PRIMARY_CONTACT = dc_s.PRIMARY_CONTACT
        ,dc_t.SECONDARY_CONTACT = dc_s.SECONDARY_CONTACT
        ,dc_t.BILLING_CYCLE = dc_s.BILLING_CYCLE
        ,dc_t.PAYEMENT_TERM = dc_s.PAYEMENT_TERM
        ,dc_t.OFFICE_MAPPED_TO = dc_s.OFFICE_MAPPED_TO
        ,dc_t.TAN_NO = dc_s.TAN_NO
        ,dc_t.PAN_NO = dc_s.PAN_NO
        ,dc_t.CUR_STATUS = dc_s.CUR_STATUS
        ,dc_t.BUSINESS_TYPE = dc_s.BUSINESS_TYPE
        ,dc_t.SAP_TIMESTAMP = dc_s.SAP_TIMESTAMP
        ,dc_t.PHONE = dc_s.PHONE
        ,dc_t.MOBILE = dc_s.MOBILE
        ,dc_t.EMAIL = dc_s.EMAIL
        ,dc_t.LEGACY_CUSTOMER_CODE = dc_s.LEGACY_CUSTOMER_CODE
        ,dc_t.RATE_CUSTOMER_CATEGORY_ID = dc_s.RATE_CUSTOMER_CATEGORY_ID
        ,dc_t.CUSTOMER_CATEGORY_CODE = dc_s.CUSTOMER_CATEGORY_CODE
        ,dc_t.CUSTOMER_CATEGORY_NAME = dc_s.CUSTOMER_CATEGORY_NAME
        ,dc_t.CUSTOMER_TYPE_ID = dc_s.CUSTOMER_TYPE_ID
        ,dc_t.CUSTOMER_TYPE_CODE = dc_s.CUSTOMER_TYPE_CODE
        ,dc_t.CUSTOMER_TYPE_DESC = dc_s.CUSTOMER_TYPE_DESC
        ,dc_t.CUSTOMER_GROUP_ID = dc_s.CUSTOMER_GROUP_ID
        ,dc_t.CUSTOMER_GROUP_CODE = dc_s.CUSTOMER_GROUP_CODE
        ,dc_t.CUSTOMER_GROUP_NAME = dc_s.CUSTOMER_GROUP_NAME
        ,LAST_UPDT_DATE=NOW()
    WHERE dc_t.CUSTOMER_CODE = dc_s.CUSTOMER_CODE; 
commit;     

-- Insert new records
insert into ff_dim_customer
select X.* from
(select 
	c.created_date as cust_created_date,
	c.updated_date as cust_updated_date,
	fn_seq_gen('n_cust_skey') AS N_CUST_SKEY, 
       c.CUSTOMER_ID,
       c.CONTRACT_NO,
       c.CUSTOMER_CODE,
       o.OFFICE_CODE AS SALES_OFFICE_CODE,
       o.office_name AS SALES_OFFICE,
       concat(e.first_name,' ',e.last_name) AS SALES_PERSON,
       ic.industry_category_name AS INDUSTRY_CATEGORY,
       it.industry_type_name AS INDUSTRY_TYPE,
       c.DISTRIBUTION_CHANNELS,
       c.BUSINESS_NAME,
       c.ADDRESS,
       c.PRIMARY_CONTACT,
       c.SECONDARY_CONTACT,
       c.BILLING_CYCLE,
       c.PAYEMENT_TERM,
       c.OFFICE_MAPPED_TO,
       c.TAN_NO,
       c.PAN_NO,
       c.CUR_STATUS,
       c.BUSINESS_TYPE,
       c.SAP_TIMESTAMP,
       c.PHONE,
       c.MOBILE,
       c.EMAIL,
       c.LEGACY_CUSTOMER_CODE,
       cc.RATE_CUSTOMER_CATEGORY_ID,
       cc.CUSTOMER_CATEGORY_CODE,
       cc.CUSTOMER_CATEGORY_NAME,
       ct.CUSTOMER_TYPE_ID,
       ct.CUSTOMER_TYPE_CODE,
       ct.CUSTOMER_TYPE_DESC,
       cg.CUSTOMER_GROUP_ID,
       cg.CUSTOMER_GROUP_CODE,
       cg.CUSTOMER_GROUP_NAME,
       CURRENT_DATE LAST_UPDT_DATE
  FROM ff_d_customer c
       LEFT JOIN ff_d_rate_customer_category cc
          ON c.customer_category = cc.rate_customer_category_id
       LEFT JOIN ff_d_customer_type ct
          ON c.customer_type = ct.customer_type_id
       LEFT JOIN ff_d_customer_group cg
          ON c.group_key = cg.customer_group_id
       LEFT JOIN ff_d_employee e
          ON e.EMPLOYEE_ID = c.SALES_PERSON
       LEFT JOIN ff_d_office o
          ON o.office_id = c.SALES_OFFICE
       LEFT JOIN ff_d_office o1
          ON o1.office_id = c.OFFICE_MAPPED_TO
       LEFT JOIN ff_d_rate_industry_category ic
          ON c.INDUSTRY_CATEGORY = ic.RATE_INDUSTRY_CATEGORY_ID
       LEFT JOIN ff_d_rate_industry_type it
          ON c.INDUSTRY_TYPE = it.rate_industry_type_id) X,
(select a.CUSTOMER_CODE
from ff_d_customer a 
left outer join ff_dim_customer b on a.CUSTOMER_CODE = b.CUSTOMER_CODE
where b.CUSTOMER_CODE is null and  a.CUSTOMER_CODE is not null) Y
where X.CUSTOMER_CODE=Y.CUSTOMER_CODE;
commit;

	
END;
