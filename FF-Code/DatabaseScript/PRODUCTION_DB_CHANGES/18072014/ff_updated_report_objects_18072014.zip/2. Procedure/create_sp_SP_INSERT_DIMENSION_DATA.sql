DROP PROCEDURE IF EXISTS sp_insert_dimension_data;
CREATE PROCEDURE sp_insert_dimension_data()
BEGIN

call sp_scd_ff_dim_product ();

call sp_scd_ff_dim_geography ();

call sp_scd_ff_dim_customer ();

END;