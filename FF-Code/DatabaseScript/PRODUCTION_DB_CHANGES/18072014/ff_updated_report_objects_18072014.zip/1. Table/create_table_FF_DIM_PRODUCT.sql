DROP TABLE IF EXISTS ff_dim_product;
CREATE TABLE `ff_dim_product` (
  `N_PROD_SKEY` int(11) NOT NULL,
  `PRODUCT_ID` int(11),
  `PRODUCT_CODE` varchar(8),
  `PRODUCT_NAME` varchar(50),
  `PRODUCT_DESC` varchar(100),
  `CONSG_SERIES` varchar(1),
  `PRODUCT_CLASSIFICATION`varchar(1),
  `CONSOLIDATION_WINDOW` int(11),
  `RATE_PROD_PROD_CAT_MAP_ID` int(11),
  `RATE_PRODUCT_CATEGORY_ID` int(11),
  `PRODUCT_CATEGORY_CODE` varchar(10),
  `PRODUCT_CATEGORY_NAME` varchar(20),
  `RATE_PRODUCT_CATEGORY_TYPE` varchar(1),
  `CALCULATION_TYPE` varchar(3),
  `DISTRIBUTION_CHANNEL` varchar(10),
  `PROD_GROUP_ID` int(11),
  `PROD_GROUP_CODE` varchar(10),
  `PROD_GROUP_NAME` varchar(100),
  `LAST_UPDT_DATE` TIMESTAMP,
  KEY `idx_dp2` (`PRODUCT_ID`),
  UNIQUE KEY `idx_dp1` (`N_PROD_SKEY`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;