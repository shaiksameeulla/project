USE CorpUDAAN;
drop EVENT  IF  EXISTS refresh_report_data;