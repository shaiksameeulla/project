package com.jcg.examples.main;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;

import com.jcg.examples.bean.RecordBean;
import com.jcg.examples.repository.RecordRepository;
import com.jcg.examples.service.GemfireTemplateService;

public class ApplicationWithGemfireClientTx2 {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext();
		context.setConfigLocation(new ClassPathResource("resources/gemfire_client_tx.xml").getPath());
		context.refresh();
		GemfireTemplateService gemfireTemplateService = context.getBean(GemfireTemplateService.class);
		showAllRecords(gemfireTemplateService);
		RecordRepository recordRepository = context.getBean(RecordRepository.class);
		System.out.println("Deleting all the existing records ***START****");
		RecordBean recordbean=recordRepository.findOne(40001);
		recordbean.setRecordString("from clientTX111");
		List<RecordBean> recordBeanList = new ArrayList<>(1);
		recordBeanList.add(recordbean);
		gemfireTemplateService.saveTransaction(recordBeanList);
		showAllRecords(gemfireTemplateService);
	}

	private static void showAllRecords(GemfireTemplateService gemfireTemplateService) {
		List<RecordBean> recordCollection = gemfireTemplateService.findAll();
		System.out.println("showAllRecords *START** ");
		for (RecordBean recordBean : recordCollection) {
			System.out.println(recordBean);

		}
		System.out.println("showAllRecords: *END** ");
	}

	
}
