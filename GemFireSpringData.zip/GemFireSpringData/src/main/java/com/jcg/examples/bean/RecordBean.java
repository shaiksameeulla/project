package com.jcg.examples.bean;


import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.PersistenceConstructor;
import org.springframework.data.gemfire.mapping.Region;


@Region("record")
public class RecordBean implements Serializable
{


		private static final long serialVersionUID = 3209342518270638000L;

		public RecordBean(){}
		@Id
		private Integer recordId;

		private String recordString;
		private Date transactionCreateDate = Calendar.getInstance().getTime();

		@PersistenceConstructor
		public RecordBean(Integer recordId, String recordString)
		{
				this.recordId = recordId;
				this.recordString = recordString;
		}

		public Integer getRecordId()
		{
				return recordId;
		}

		public void setRecordId(Integer recordId)
		{
				this.recordId = recordId;
		}

		public String getRecordString()
		{
				return recordString;
		}

		public void setRecordString(String recordString)
		{
				this.recordString = recordString;
		}

		@Override
		public String toString()
		{
				return "RecordBean [Record Id=" + recordId + ", Record String=" + recordString + "]";
		}

		/**
		 * @return the transactionCreateDate
		 */
		public Date getTransactionCreateDate() {
			return transactionCreateDate;
		}

		/**
		 * @param transactionCreateDate the transactionCreateDate to set
		 */
		public void setTransactionCreateDate(Date transactionCreateDate) {
			this.transactionCreateDate = transactionCreateDate;
		}

}
