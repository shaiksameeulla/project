/**
 * 
 */
package com.jcg.examples.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.gemfire.GemfireTemplate;
import org.springframework.stereotype.Repository;

import com.gemstone.gemfire.cache.query.SelectResults;
import com.jcg.examples.bean.RecordBean;

/**
 * @author mohammes
 *
 */
@Repository
public class GemfireTemplateRecordDAOImpl implements GemfireTemplateRecordDAO {
	
	@Autowired
	GemfireTemplate recordTemplate;
	
	@Override
	public List<RecordBean> findRecordDetailsById(Integer recordId) {
		SelectResults<RecordBean> orders = recordTemplate.find("SELECT * from /record WHERE recordId = $1", recordId);
		return (orders == null)?null : orders.asList();
	}
	@Override
	public List<RecordBean> findAll() {
		SelectResults<RecordBean> orders = recordTemplate.find("SELECT * from /record ");
		return (orders == null)?null : orders.asList();
	}
	@Override
	public void delete(Integer recordId) {
		recordTemplate.remove(recordId);
	}

	@Override
	public RecordBean save(RecordBean recordBean) {
		return recordTemplate.put(recordBean.getRecordId(), recordBean);
	}
	
	@Override
	public void save(List<RecordBean> recordBean) {
		Map<Integer,RecordBean> map= new HashMap<>(recordBean.size());
		for(RecordBean rb: recordBean){
			System.out.println("GemfireTemplateRecordDAOImpl :: save :: "+rb);
			map.put(rb.getRecordId(), rb);
		}
		 recordTemplate.putAll(map);
	}
	@Override
	public RecordBean get(Integer recordId) {
		return recordTemplate.get(recordId);
	}

}
