/**
 * 
 */
package com.jcg.examples.service;

import java.util.List;

import com.jcg.examples.bean.RecordBean;

/**
 * @author mohammes
 *
 */
public interface RecordService {
	void save(RecordBean recordBean);
	void save(List<RecordBean> recordBean);
	RecordBean findByRecordId(Integer recordId);
	List<RecordBean> findAll();
	
	void deleteByRecordId(Integer recordId);
	void deleteAll();
	
	void saveTransaction(List<RecordBean> recordBean);

}
