package com.jcg.examples.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.jcg.examples.bean.RecordBean;
import com.jcg.examples.dao.GemfireTemplateRecordDAO;

@Service
public class GemfireTemplateServiceImpl implements GemfireTemplateService {
	
	@Autowired
	private GemfireTemplateRecordDAO gemfireTemplateRecordDAO;
	
	@Autowired
	private RecordService recordService;

	@Override
	public void save(RecordBean recordBean) {
		recordBean.setTransactionCreateDate(new Date());
		recordService.save(recordBean);
		
	}

	@Override
	public void save(List<RecordBean> recordBean) {
		gemfireTemplateRecordDAO.save(recordBean);
		
	}

	@Override
	public RecordBean findByRecordId(Integer recordId) {
		return gemfireTemplateRecordDAO.get(recordId);
	}

	

	@Override
	public void deleteByRecordId(Integer recordId) {
		gemfireTemplateRecordDAO.delete(recordId);
		
	}

	
	@Transactional(value="gemfireTransactionManager")	
	@Override
	public void saveTransaction(List<RecordBean> recordBean) {
		
		save(recordBean.get(0));
	}

	@Override
	public List<RecordBean> findAll() {
		return gemfireTemplateRecordDAO.findAll();
	}

}
