package com.jcg.examples.main;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;

import com.jcg.examples.bean.RecordBean;
import com.jcg.examples.repository.RecordRepository;
import com.jcg.examples.service.GemfireTemplateService;

public class ApplicationWithGemfireClientTx {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext();
		context.setConfigLocation(new ClassPathResource("resources/gemfire_client_tx.xml").getPath());
		context.refresh();
		GemfireTemplateService gemfireTemplateService = context.getBean(GemfireTemplateService.class);
		showAllRecords(gemfireTemplateService);
		RecordRepository recordRepository = context.getBean(RecordRepository.class);
		System.out.println("Deleting all the existing records ***START****");
		recordRepository.deleteAll();
		System.out.println("Deleted all the existing records ***END****");
		try {
			saveDataWithTransaction(gemfireTemplateService);
		} catch (Exception e) {
			System.err.println("saveDataWithTransaction:: Exception");
			e.printStackTrace();
		}
		showAllRecords(gemfireTemplateService);
		try {
			saveDataWithoutTransaction(gemfireTemplateService);
		} catch (Exception e) {
			System.err.println("saveDataWithoutTransaction:: Exception");
			e.printStackTrace();
		}
		
		showAllRecords(gemfireTemplateService);
	}

	private static void showAllRecords(GemfireTemplateService gemfireTemplateService) {
		List<RecordBean> recordCollection = gemfireTemplateService.findAll();
		System.out.println("showAllRecords *START** ");
		for (RecordBean recordBean : recordCollection) {
			System.out.println(recordBean);

		}
		System.out.println("showAllRecords: *END** ");
	}

	private static void saveDataWithTransaction(GemfireTemplateService gemfireTemplateService) {
		System.out.println("saveDataWithTransaction ::START");
		List<RecordBean> recordBeanList = new ArrayList<>(3);
		recordBeanList.add(new RecordBean(50001, "OneTx"));
		recordBeanList.add(new RecordBean(50002, "TwoTx"));
		recordBeanList.add(new RecordBean(50003, "ThreeTx"));
		gemfireTemplateService.saveTransaction(recordBeanList);
		System.out.println("saveDataWithTransaction ::END");
	}

	private static void saveDataWithoutTransaction(GemfireTemplateService gemfireTemplateService) {
		System.out.println("saveDataWithoutTransaction ::START");
		List<RecordBean> recordBeanList = new ArrayList<>(3);
		recordBeanList.add(new RecordBean(40001, "OnewithoutTx"));
		recordBeanList.add(new RecordBean(40002, "TwowithoutTx"));
		recordBeanList.add(new RecordBean(40003, "ThreewithoutTx"));
		gemfireTemplateService.save(recordBeanList);
		System.out.println("saveDataWithoutTransaction ::START");
	}
}
