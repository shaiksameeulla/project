package com.jcg.examples.main;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;

import com.jcg.examples.bean.RecordBean;
import com.jcg.examples.repository.RecordRepository;


public class Application
{

		public static void main(String[] args)
		{
				 ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(); 
				 context.setConfigLocation(new ClassPathResource("resources/gfshBean.xml").getPath());
				 context.refresh();
				 RecordRepository recordRepository = context.getBean(RecordRepository.class);
				 List<RecordBean> recordBeanList= new ArrayList<>(3);
				 recordBeanList.add(new RecordBean("41", "One"));
				 recordBeanList.add(new RecordBean("52", "Two"));
				 recordBeanList.add(new RecordBean("63", "Three"));
				 recordRepository.save(recordBeanList);
				 System.out.println("Successful run!!");
				 
				 RecordBean recordBeanFetched = recordRepository.findByRecordId("6");
				 System.out.println("The Fetched record bean is "+recordBeanFetched);
				 
				 Iterable<RecordBean> recordCollection = recordRepository.myFindAll();
				 System.out.println("RecordBeans List : ");
				 for (Iterator<RecordBean> iterator = recordCollection.iterator(); iterator.hasNext();)
        {
						 RecordBean recordBeannew = (RecordBean) iterator.next();
						 System.out.println(recordBeannew);
		        
        }
		}
}
