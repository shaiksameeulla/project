package com.jcg.examples.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.jcg.examples.bean.RecordBean;
import com.jcg.examples.dao.RecordDAO;

@Service
public class RecordServiceImpl implements RecordService {
	
	@Autowired
	private RecordDAO recordDAO;

	@Override
	public void save(RecordBean recordBean) {
		recordDAO.save(recordBean);
		
	}

	@Override
	public void save(List<RecordBean> recordBean) {
		recordDAO.save(recordBean);
		
	}

	@Override
	public RecordBean findByRecordId(Integer recordId) {
		return recordDAO.findByRecordId(recordId);
	}

	@Override
	public List<RecordBean> findAll() {
		// TODO Auto-generated method stub
		return recordDAO.findAll();
	}

	@Override
	public void deleteByRecordId(Integer recordId) {
		recordDAO.deleteByRecordId(recordId);
		
	}

	@Override
	public void deleteAll() {
		recordDAO.deleteAll();
		
	}
	@Transactional("gemfireTransactionManager")	
	@Override
	public void saveTransaction(List<RecordBean> recordBean) {
		deleteAll();
		save(recordBean);
		if (true) {
			 throw new RuntimeException("Updated failed - should trigger a rollback.");
		 } 
		
	}

}
