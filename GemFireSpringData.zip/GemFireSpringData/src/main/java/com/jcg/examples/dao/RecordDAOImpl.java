/**
 * 
 */
package com.jcg.examples.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.jcg.examples.bean.RecordBean;
import com.jcg.examples.repository.RecordRepository;

/**
 * @author mohammes
 *
 */
@Repository
public class RecordDAOImpl implements RecordDAO{
	
	@Autowired
	private RecordRepository recordRepository;

	@Override
	public void save(RecordBean recordBean) {
		System.out.println("RecordDAOImpl :: save :: "+recordBean);
		recordRepository.save(recordBean);
		
	}

	@Override
	public void save(List<RecordBean> recordBean) {
		recordRepository.save(recordBean);
		
	}

	@Override
	public RecordBean findByRecordId(Integer recordId) {
		return recordRepository.findByRecordId(recordId);
	}

	@Override
	public List<RecordBean> findAll() {
		// TODO Auto-generated method stub
		return (List)recordRepository.findAll();
	}

	@Override
	public void deleteByRecordId(Integer recordId) {
		recordRepository.delete(recordId);
		
	}

	@Override
	public void deleteAll() {
		recordRepository.deleteAll();
		
	}

}
