package com.jcg.examples.dao;

import java.util.List;

import com.jcg.examples.bean.RecordBean;

public interface RecordDAO {
	void save(RecordBean recordBean);
	void save(List<RecordBean> recordBean);
	RecordBean findByRecordId(Integer recordId);
	List<RecordBean> findAll();
	
	void deleteByRecordId(Integer recordId);
	void deleteAll();
	

}
