/**
 * 
 */
package com.jcg.examples.dao;

import java.util.List;

import com.jcg.examples.bean.RecordBean;

/**
 * @author mohammes
 *
 */
public interface GemfireTemplateRecordDAO {

	List<RecordBean> findRecordDetailsById(Integer recordId);

	void delete(Integer recordId);

	RecordBean save(RecordBean recordBean);

	RecordBean get(Integer recordId);

	void save(List<RecordBean> recordBean);

	List<RecordBean> findAll();

}
