import React from "react";
import "./App.css";
// const name = 'john'
// const greeting = `hello my name is ${name}`
// styled-components utilises tagged template literals to style your components

function App() {
  return <div>hello from app</div>;
}

export default App;
