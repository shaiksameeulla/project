import React from "react";
import "./App.css";

function App() {
  return (
    <div>
      <h1>styled components</h1>
    </div>
  );
}

export default App;
