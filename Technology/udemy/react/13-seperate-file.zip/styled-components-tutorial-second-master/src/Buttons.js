import styled from "styled-components";

export const Button = styled.button`
  color: red;
  background: blue;
  text-transform: uppercase;
`;
export const SecondButton = styled.button`
  color: blue;
  background: red;
  text-transform: uppercase;
`;
