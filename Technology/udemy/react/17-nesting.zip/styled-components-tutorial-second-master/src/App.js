import React from "react";
import "./App.css";
import StyledHeader from "./components/StyledHeader";
function App() {
  return (
    <div>
      <StyledHeader />
    </div>
  );
}

export default App;
