import React from "react";
import "./App.css";
// inline css
// app css
// css variables
// file css
function App() {
  return (
    <div>
      <h1>styled components</h1>
      <h2 style={{ color: "red", textTransform: "uppercase" }}>
        inline styles
      </h2>
    </div>
  );
}

export default App;
