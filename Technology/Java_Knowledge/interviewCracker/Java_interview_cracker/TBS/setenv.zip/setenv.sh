# Edit this file to set custom options
# Tomcat accepts two parameters JAVA_OPTS and CATALINA_OPTS
# JAVA_OPTS are used during START/STOP/RUN
# CATALINA_OPTS are used during START/RUN

JAVA_HOME="/opt/tomcat/spring/java/jdk1.7.0_65"

gc_threads=`expr $(cat /proc/cpuinfo  | grep processor | wc -l) / 2`; ret_val=$?

if [ ${ret_val} -ne 0 ] || [ ${gc_threads} -lt 2 ]; then
  gc_threads=2
fi

#Setting the Debug Arguments , enable (uncomment) If necessary.
DEBUG_ARGS="-Xdebug -Xrunjdwp:transport=dt_socket,address=26114,server=y,suspend=n"

#TO ENABLE PROXY UNCOMMENT THESE
#NON_PROXY_HOSTS="localhost|[HOST]*"
#PROXY_ARGS="-Dhttp.proxyHost=<specify_proxy>.swacorp.com -Dhttp.proxyPort=8080 -Dhttp.nonProxyHosts=$NON_PROXY_HOSTS"

AGENT_PATHS=""
JAVA_AGENTS=""
JAVA_LIBRARY_PATH=""
JVM_OPTS="-Xss256K -Dtomcat.env=DEV -Dtomcat.host=xldcarcsi03 -Dtomcat.name=cargoadminservices_1.2.78-A -Dtomcat.hangar=DEV1 -Dtomcat.alertLogFile=/opt/catlogs/service_alerts/cargoadminservices/service_alert.xldcarcsi03.log -server -XX:PermSize=64M -XX:MaxPermSize=128M -XX:+UseParallelOldGC -XX:ParallelGCThreads=$gc_threads -XX:NewRatio=3 -verbose:gc -XX:+PrintGC -XX:+PrintGCDetails -XX:+PrintTenuringDistribution -Xloggc:$CATALINA_BASE/logs/verbosegc.log -Djavax.net.ssl.trustStore=/opt/tcsadmin/etc/keystores/tcserver.xldcarcsi03.keystore -Djavax.net.ssl.trustStorePassword=changeme -Dvflicense.properties.dir=$CATALINA_BASE/conf -DSVID=cargoadminservices_1_2_78 -Dtomcat.serviceConsoleGroup=Cargo -Xms1024M -Xmx1024M"
JAVA_OPTS="$JVM_OPTS $DEBUG_ARGS $PROXY_ARGS $AGENT_PATHS $JAVA_AGENTS $JAVA_LIBRARY_PATH"
