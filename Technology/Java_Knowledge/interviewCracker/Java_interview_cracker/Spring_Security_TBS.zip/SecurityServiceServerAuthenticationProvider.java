package com.swacorp.tbs.security.providers;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.core.Authentication;

import com.swacorp.tbs.security.exceptions.BaseSecurityException;
import com.swacorp.tbs.security.exceptions.InvalidTokenException;
import com.swacorp.tbs.security.securityservice.wrapper.SecurityServiceAdapter;
import com.swacorp.tbs.security.securityservice.wrapper.UserDetails;
import com.swacorp.tbs.security.util.TBSCache;

/**
 * AuthenticationProvider that verifies the Security service generated token.
 */

public class SecurityServiceServerAuthenticationProvider implements AuthenticationProvider {

   private static final Logger LOGGER = LogManager
         .getLogger(SecurityServiceServerAuthenticationProvider.class);
   private List<IVerifier> preVerifiers;
   private List<IVerifier> postVerifiers;
   private TBSCache<String, UserDetails> cache;
   private SecurityServiceAdapter securityServiceClient;

   public SecurityServiceServerAuthenticationProvider(TBSCache<String, UserDetails> cache,
         List<IVerifier> preVerifiers, List<IVerifier> postVerifiers,
         SecurityServiceAdapter securityServiceClient) {
      super();
      this.cache = cache;
      this.preVerifiers = preVerifiers;
      this.postVerifiers = postVerifiers;
      this.securityServiceClient = securityServiceClient;
      checkVerifiers();
   }

   public SecurityServiceServerAuthenticationProvider(List<IVerifier> preVerifiers,
         List<IVerifier> postVerifiers, SecurityServiceAdapter securityServiceClient) {
      super();
      this.preVerifiers = preVerifiers;
      this.postVerifiers = postVerifiers;
      this.securityServiceClient = securityServiceClient;
      checkVerifiers();
   }

   private void checkVerifiers() {

      if (preVerifiers == null) {
         String msg = "No Pre Verifiers have been configured.";
         LOGGER.info(msg);
         preVerifiers = new ArrayList<IVerifier>();
      }

      if (postVerifiers == null) {
         String msg = "No Post Verifiers have been configured";
         LOGGER.info(msg);
         postVerifiers = new ArrayList<IVerifier>();
      }

      if (LOGGER.isDebugEnabled()) {
         LOGGER.debug("Configured with verifiers: pre# " + preVerifiers.size() + " post# "
               + postVerifiers.size());
      }

   }

   public void setCache(TBSCache<String, UserDetails> cache) {
      this.cache = cache;
   }

   /**
    * Authenticate using the provided token.
    * 
    * @param auth
    *           Authentication details containing the token. (partial authentication information).
    * @return an empty Authentication--if no exception is thrown, the incoming auth is valid.
    * @throws SecurityTokenNotFoundException
    *            -- if token based authentication fails. FWSecurityException generic exception if
    *            verification fails.
    * @see org.springframework.security.providers.AuthenticationProvider#authenticate
    *      (org.springframework.security.Authentication)
    */
   @Override
   public final Authentication authenticate(final Authentication auth) {
      if (LOGGER.isDebugEnabled()) {
         LOGGER.debug("Authenticating " + auth);
      }

      ServerAuthenticationToken authToken = (ServerAuthenticationToken) auth;

      for (IVerifier verifier : preVerifiers) {
         verifier.verify(authToken);
      }

      String securityToken = authToken.getToken();
      if ((securityToken == null) || (securityToken.length() == 0)) {
         String msg = "Security token is null or empty.";
         LOGGER.error(msg);
         throw new BaseSecurityException(msg);
      }

      UserDetails authenticatedUser = this.findUser(securityToken);
      checkAuthenticatedUser(securityToken, authenticatedUser);
      AccessibleHeadersContext.getHeader().setDetails(authenticatedUser);

      ServerAuthenticationToken returnAuth = new ServerAuthenticationToken(authToken.getTimestamp(),
            authToken.getToken(), authToken.getHeaderSignature(), authToken.getPayloadSignature(),authToken.getPayload(),
            authenticatedUser.getGroups(), authenticatedUser.getUser());
      returnAuth.setDetails(authenticatedUser);
      for (IVerifier verifier : postVerifiers) {
         verifier.verify(returnAuth);
      }

      return returnAuth;

   }

   /**
    * This method will first check the userCache for an entry at securityToken. If nothing is found
    * in the cache, it will then ask the securityService.
    * 
    * @param securityService
    * @param userCache
    * @param securityToken
    * @return null if no entry is found for the securityToken in either the cache or the
    *         securityService
    */
   private UserDetails findUser(String securityToken) {
      UserDetails authenticatedUser = null;
      if (this.cache != null) {
         authenticatedUser = this.cache.get(securityToken);
      }

      if (authenticatedUser != null) {
         if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Found security token - " + securityToken + " - in local cache.");
         }
      } else {
         LOGGER.info("Looking up security token in SecurityService " + securityToken);
         authenticatedUser = securityServiceClient.lookupUser(securityToken);

         if (this.cache != null && authenticatedUser != null) {
            this.cache.put(securityToken, authenticatedUser);
         }
      }
      // Must return an AuthenticatedUser so that we
      // can access the public key
      return authenticatedUser;
   }

   /**
    * 
    * @throws SecurityTokenNotFoundException
    *            -- if authenticatedUser is null
    */
   private void checkAuthenticatedUser(String securityToken, Object authenticatedUser) {
      if (authenticatedUser == null) {
         // may be security service cache has aged out the security token
         // client needs to reauthenticate and resend the request
         String msg = "Security token - " + securityToken
               + " - not found in local cache and security service.";
         LOGGER.info(msg);
         throw new InvalidTokenException(msg);
      }
   }

   /**
    * Returns true for TokenTimestampAndSignatureAuthenticationToken class.
    * 
    * @param klass
    *           the class of the AuthenticationToken that is passed.
    * @return boolean indicating whether the current class supports the passed authentication token.
    * @see org.springframework.security.providers.AuthenticationProvider#supports(java.lang.Class)
    */
   @Override
   public final boolean supports(final Class<?> klass) {
      return klass == ServerAuthenticationToken.class;
   }
}
