package com.swacorp.tbs.security.providers;


import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.springframework.security.access.ConfigAttribute;
import org.springframework.security.access.SecurityConfig;
import org.springframework.security.access.SecurityMetadataSource;

import com.swacorp.tbs.authorization.BWSecurityMetadataSource;
import com.swacorp.tbs.authorization.ResourceEntry;

/**
 * Class which defines the object definition source used for spring based authorization. user is
 * authorized for access.
 * 
 * @author x14280
 * 
 */
public class AuthorizationSecurityMetadataSource implements SecurityMetadataSource {

   private static final Logger LOGGER = Logger.getLogger(AuthorizationSecurityMetadataSource.class);
   private static final int DEFAULT_PATTERN_FLAGS = 0;
   /**
    * HashMap containing the configuration attributes, keyed by string value defined in
    * configuration file For example, key="aafexample/CustomerService.*" denotes all operations for
    * CustomerService service and value = SF_fwadmin_S denotes the role required to invoke
    * operations for the given key.
    */
   private Map<Pattern, List<ConfigAttribute>> attributes = new LinkedHashMap<Pattern, List<ConfigAttribute>>();

   private Map<String, String> authDefinitions;

   private int patternFlags = DEFAULT_PATTERN_FLAGS;

   public AuthorizationSecurityMetadataSource() {
      super();
   }

   public AuthorizationSecurityMetadataSource(BWSecurityMetadataSource dataSource) {
      super();
      setAuthDefinitions(dataSource);
   }

   public AuthorizationSecurityMetadataSource(int patternFlags) {
      super();
      this.patternFlags = patternFlags;
   }

   public int getPatternFlags() {
      return patternFlags;
   }

   public void setPatternFlags(int patternFlags) {
      this.patternFlags = patternFlags;
   }

   /**
    * sets the attributes hashMap from the configuration defined for the object definition source.
    * 
    * @param authDefinitions
    *           properties loaded from the configuration file.
    */
   public void setAuthDefinitions(BWSecurityMetadataSource bwAuthSource) {

      Map<String, String> authDef = new HashMap<String, String>();
      List<ResourceEntry> entryList = bwAuthSource.getResourceEntry();
      for (ResourceEntry entry : entryList) {
         authDef.put(entry.getResource(), entry.getAuthorities());
      }
      
      this.authDefinitions = authDef;

      for (Map.Entry<String, String> entry : authDefinitions.entrySet()) {
         String key = entry.getKey();
         Pattern pattern = Pattern.compile(key, patternFlags);
         String value = entry.getValue();
         List<ConfigAttribute> cfgAtt = SecurityConfig.createListFromCommaDelimitedString(value);
         attributes.put(pattern, cfgAtt);
      }
   }

   /**
    * sets the attributes hashMap from the configuration defined for the object definition source.
    * 
    * @param authDefinitions
    *           properties loaded from the configuration file.
    */
   public void setAuthDefinitions(Map<String, String> authDefinitions) {

      this.authDefinitions = authDefinitions;

      for (Map.Entry<String, String> entry : authDefinitions.entrySet()) {
         String key = entry.getKey();
         Pattern pattern = Pattern.compile(key, patternFlags);
         String value = entry.getValue();
         List<ConfigAttribute> cfgAtt = SecurityConfig.createListFromCommaDelimitedString(value);
         attributes.put(pattern, cfgAtt);
      }
   }

   public Map<String, String> getAuthDefinitions() {
      return authDefinitions;
   }

   @Override
   public Collection<ConfigAttribute> getAttributes(Object key) throws IllegalArgumentException {
      if (!(key instanceof java.lang.String)) {
         throw new IllegalArgumentException("Object Definition expecting String key");
      }

      String keyString = (String) key;
      List<ConfigAttribute> cfg = null;
      for (Pattern pattern : attributes.keySet()) {
         Matcher matcher = pattern.matcher(keyString);
         if (matcher.matches()) {
            cfg = attributes.get(pattern);
            break;
         }
      }
      LOGGER.debug("Defined authorizations: " + this.attributes);
      if (cfg == null) {
         LOGGER.warn("UNSECURE SERVICE: Failed to find authorization record for " + key);
      }
      return cfg;
   }

   @Override
   public Collection<ConfigAttribute> getAllConfigAttributes() {
      List<ConfigAttribute> allConfigAttributes = new ArrayList<ConfigAttribute>();
      Set<Entry<Pattern, List<ConfigAttribute>>> allEntries = attributes.entrySet();

      for (Entry<Pattern, List<ConfigAttribute>> entry : allEntries) {
         allConfigAttributes.addAll(entry.getValue());
      }
      return allConfigAttributes;
   }

   @Override
   public boolean supports(Class<?> clazz) {
      return String.class.isAssignableFrom(clazz);
   }

}
