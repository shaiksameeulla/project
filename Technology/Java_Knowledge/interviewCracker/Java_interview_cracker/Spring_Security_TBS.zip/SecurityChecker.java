package com.swacorp.tbs.security.service.penta;

import static com.swacorp.tbs.security.penta.OoBHeaderConstants.HEADER_SIGNATURE;
import static com.swacorp.tbs.security.penta.OoBHeaderConstants.MESSAGE_VERSION;
import static com.swacorp.tbs.security.penta.OoBHeaderConstants.PAYLOAD_SIGNATURE;
import static com.swacorp.tbs.security.penta.OoBHeaderConstants.SECURITY_TOKEN;
import static com.swacorp.tbs.security.penta.OoBHeaderConstants.TIMESTAMP;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.apache.cxf.common.util.UrlUtils;

import com.swacorp.tbs.security.core.SecurityCoreServerImpl;
import com.swacorp.tbs.security.exceptions.BaseSecurityException;
import com.swacorp.tbs.security.exceptions.HttpHeaderConstants;
import com.swacorp.tbs.security.exceptions.InvalidTokenException;
import com.swacorp.tbs.security.penta.OoBHeader;
import com.swacorp.tbs.security.penta.OoBHeaderConstants;
import com.swacorp.tbs.security.providers.AccessibleHeaders;
import com.swacorp.tbs.security.providers.AccessibleHeadersContext;
import com.swacorp.tbs.security.providers.ServerAuthenticationToken;
import com.swacorp.tbs.security.util.CanonicalizationUtilities;
import com.swacorp.tbs.security.util.StackTraceUtility;

public class SecurityChecker {

   private SecurityCoreServerImpl securityCoreServer;

   private boolean payloadVerificationEnabled = false;
   private boolean groupAuth = false;
   private static final String AUTHORIZATION_ERROR_MSG = "Error authorizing with Authentication Request :\n ";

   private static final Logger LOGGER = LogManager.getLogger(SecurityChecker.class);

   public SecurityChecker(SecurityCoreServerImpl scServer, boolean payloadVerificationEnabled,
         boolean groupAuth) {
      securityCoreServer = scServer;
      this.payloadVerificationEnabled = payloadVerificationEnabled;
      this.groupAuth = groupAuth;
   }

   /**
    * derive the security information from the data passed into the httpServlet request headers.
    * Concrete classes will provide the implementation specific ISecurityInformation.
    * 
    * @param httpServletRequest
    *           containing the headers like token, group etc
    * @return ISecurityInformation which contains the implementation specific data used to verify
    *         the request.
    */
   protected ServerAuthenticationToken getSecurityInformation(HttpServletRequest httpServletRequest,
         String payload) {

      ServerAuthenticationToken securityInformation = null;

      if (groupAuth) {
         String groups = httpServletRequest.getHeader("x-groups");
         if (groups != null && groups.length() != 0) {

            List<GrantedAuthority> auths = new ArrayList<>();
            StringTokenizer st = new StringTokenizer(groups, ":");
            while (st.hasMoreTokens()) {
               String group = st.nextToken();
               if (group != null) {
                  group = group.toUpperCase();
               }
               SimpleGrantedAuthority sga = new SimpleGrantedAuthority(group);
               auths.add(sga);
            }
            // create a new verify authentication token.
            securityInformation = new ServerAuthenticationToken(httpServletRequest.getHeader("x-userId"),
                  auths);
            AccessibleHeadersContext.setHeader(new AccessibleHeaders());
            return securityInformation;
         }
      }
      // Support for Pre-penta security compatibility...
      if (httpServletRequest.getHeader("x-securityToken") != null
            && httpServletRequest.getHeader(SECURITY_TOKEN) == null) {
         securityInformation = new ServerAuthenticationToken(httpServletRequest.getHeader("x-timestamp"),
               httpServletRequest.getHeader("x-securityToken"),
               httpServletRequest.getHeader("x-tokenSignature"),
               httpServletRequest.getHeader("x-payloadSignature"), payload,
               ServerAuthenticationToken.AuthenticationType.PRE_PENTA);
         AccessibleHeadersContext.setHeader(new AccessibleHeaders());
         return securityInformation;
      }

      securityInformation = new ServerAuthenticationToken(httpServletRequest.getHeader(TIMESTAMP),
            httpServletRequest.getHeader(SECURITY_TOKEN), httpServletRequest.getHeader(HEADER_SIGNATURE),
            httpServletRequest.getHeader(PAYLOAD_SIGNATURE), payload);
      if (httpServletRequest.getHeader(MESSAGE_VERSION) == null) {
         securityInformation.setAuthenticationType(ServerAuthenticationToken.AuthenticationType.UNKNOWN);
      }
      Map<String, String> reqHeaders = new HashMap<>();
      for (String headerName : OoBHeaderConstants.getRequestHeaders()) {
         addToMap(reqHeaders, httpServletRequest, headerName);
      }
      OoBHeader header = OoBHeader.fromMap(reqHeaders);
      AccessibleHeadersContext.setHeader(new AccessibleHeaders(header));
      return securityInformation;
   }

   private void addToMap(Map<String, String> reqHeaders, HttpServletRequest httpServletRequest,
         String headerName) {
      String headerValue = httpServletRequest.getHeader(headerName);
      if (headerValue != null) {
         reqHeaders.put(headerName, headerValue);
      }
   }

   /**
    * Add the exception details to the HTTP header.
    * 
    * @param response
    *           the response object.
    * @param exception
    *           the exception that was encountered.
    * @param resourceIdentifier
    * @param errorCode
    * @throws IOException
    */
   protected void populateExceptionResponse(HttpServletResponse response, final Exception exception,
         final ServerAuthenticationToken authentication, final int errorCode) throws IOException {
      String msg = AUTHORIZATION_ERROR_MSG + authentication + " Exception is \n" + exception.getMessage();
      String exceptionName = exception.getClass().getName();

      // log the stack trace.
      String stackTrace = StackTraceUtility.stackTraceToString(exception);
      LOGGER.error("Received exception " + exceptionName + "\n Message =  " + msg + "\n stacktrace = \n"
            + stackTrace);
      response.reset();
      response.setStatus(errorCode);
      if (authentication.isPrePentaCompatible()) {
         response.setHeader(HttpHeaderConstants.ERROR_CODE, String.valueOf(errorCode));
         response.setHeader(HttpHeaderConstants.ERROR_EXCEPTION_CLASS, exceptionName);
         response.setHeader(HttpHeaderConstants.ERROR_MESSAGE, exception.getMessage());
      }
      // set the errors in the http header.
      if (authentication.isPentaCompatible()) {
         response.setHeader(OoBHeaderConstants.RESPONSE_CODE, String.valueOf(errorCode));
         response.setHeader(OoBHeaderConstants.ERROR_EXCEPTION_CLASS, exceptionName);
         response.setHeader(OoBHeaderConstants.ERROR_MESSAGE, exception.getMessage());
      }
   }

   public void enforceSecurity(HttpServletRequest httpServletRequest, ServletResponse response, String body)
      throws IOException {

      ServerAuthenticationToken securityInformation = null;

      String resource = httpServletRequest.getHeader("soapAction");
      if (resource != null) {
         resource = resource.replaceAll("^\"|\"$", "");
         securityInformation = getSecurityInformation(httpServletRequest, body);
      } else {
         resource = httpServletRequest.getMethod() + httpServletRequest.getPathInfo();
         securityInformation = getSecurityInformation(httpServletRequest, getRestPayloadAddition(httpServletRequest) + body);
      }
      HttpServletResponse httpResponse = (HttpServletResponse) response;
      try {
         // invoke call on the core server API to authorize.
         securityCoreServer.authorize(securityInformation, resource);

      } catch (InvalidTokenException e) {
         // re-authentication is required since token was not found.
         populateExceptionResponse(httpResponse, e, securityInformation,
               HttpServletResponse.SC_PRECONDITION_FAILED);
         throw new BaseSecurityException(e.getMessage(), e.getCause());
      } catch (BaseSecurityException e) {
         // any exception within the BaseSecurityException hierarchy.
         populateExceptionResponse(httpResponse, e, securityInformation, HttpServletResponse.SC_FORBIDDEN);
         throw new BaseSecurityException(e.getMessage(), e.getCause());
      } catch (Exception e) {
         // other runtime exceptions.
         populateExceptionResponse(httpResponse, e, securityInformation,
               HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
         throw new BaseSecurityException(e.getMessage(), e.getCause());
      }
   }

   private String getRestPayloadAddition(HttpServletRequest httpServletRequest) {
      String requestUri = UrlUtils.urlDecode(httpServletRequest.getRequestURI());
      return new StringBuilder().append(httpServletRequest.getMethod())
                                 .append(requestUri) //httpServletRequest.getRequestURI())
                                 .append(CanonicalizationUtilities.canonicalizeQueryString(httpServletRequest.getQueryString())) //(httpServletRequest.getQueryString() == null ? "" : httpServletRequest.getQueryString()))
                                 .toString();
   }
   
   public boolean isPayloadVerificationEnabled() {
      return payloadVerificationEnabled;
   }

   public void setPayloadVerificationEnabled(boolean payloadVerificationEnabled) {
      this.payloadVerificationEnabled = payloadVerificationEnabled;
   }
}
