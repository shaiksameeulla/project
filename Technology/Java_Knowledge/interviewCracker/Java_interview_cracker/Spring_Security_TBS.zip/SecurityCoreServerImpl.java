/**
 * Project: tbs-security-core
 *
 * SecurityCoreServerImpl.java
 *
 * Copyright (c) 2013 Southwest Airlines Co.
 * 2702 Love Field Drive, Dallas, TX 75235, USA
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Southwest Airlines Co.
 */
package com.swacorp.tbs.security.core;

import org.apache.log4j.Level;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import com.swacorp.tbs.security.exceptions.AuthorizationException;
import com.swacorp.tbs.security.exceptions.BaseSecurityException;
import com.swacorp.tbs.security.exceptions.SecurityServiceException;
import com.swacorp.tbs.security.providers.AuthorizationSecurityInterceptor;
import com.swacorp.tbs.security.providers.ServerAuthenticationToken;
import com.swacorp.tbs.security.util.SecurityAuditLogUtil;
import com.swacorp.tbs.security.util.SecurityAuditLogUtil.SECURITY_AUDIT_LOGS;

public class SecurityCoreServerImpl {

   // logger.
   private static final Logger LOGGER = LogManager.getLogger(SecurityCoreServerImpl.class);

   // class name, used for messages.
   private String className = this.getClass().getSimpleName();

   // spring security intercepter, defined in a spring context.
   private AuthorizationSecurityInterceptor authorizationInterceptor;

   // flag indicating whether security is enabled.
   private boolean isSecurityEnabled;

   // anonymous mode.
   protected Authentication anonymousAuthenticationToken;

   /**
    * overloaded constructor.
    * 
    * @param isSecurityEnabled
    */
   public SecurityCoreServerImpl(final boolean isSecurityEnabled,
         final AuthorizationSecurityInterceptor authorizationInterceptor,
         final Authentication anonymousAuthenticationToken) {
      super();
      this.isSecurityEnabled = isSecurityEnabled;
      this.authorizationInterceptor = authorizationInterceptor;
      this.anonymousAuthenticationToken = anonymousAuthenticationToken;
   }

   /**
    * overloaded constructor.
    * 
    * @param isSecurityEnabled
    */
   public SecurityCoreServerImpl(final boolean isSecurityEnabled) {
      super();
      this.isSecurityEnabled = isSecurityEnabled;
   }

   /**
    * @return the anonymousAuthenticationToken
    */
   public Authentication getAnonymousAuthenticationToken() {
      return anonymousAuthenticationToken;
   }

   /**
    * @param anonymousAuthenticationToken
    *           the anonymousAuthenticationToken to set
    */
   public void setAnonymousAuthenticationToken(Authentication anonymousAuthenticationToken) {
      this.anonymousAuthenticationToken = anonymousAuthenticationToken;
   }

   /**
    * Access the interceptor.
    * 
    * @return An instance on the security interceptor.
    */
   public AuthorizationSecurityInterceptor getAuthorizationInterceptor() {
      return authorizationInterceptor;
   }

   /**
    * mutate - injected via spring.
    * 
    * @param authorizationInterceptor
    *           the authorization interceptor.
    */
   public void setAuthorizationInterceptor(final AuthorizationSecurityInterceptor authorizationInterceptor) {
      this.authorizationInterceptor = authorizationInterceptor;
   }

   public void authorize(ServerAuthenticationToken securityInformation, final String resource)
      throws SecurityServiceException, AuthorizationException, BaseSecurityException {
      Authentication authentication = securityInformation;
      if (LOGGER.isDebugEnabled()) {
         LOGGER.debug(className + "::authorize, operation name = " + resource);
      }

      if (!isSecurityEnabled) {
         return;
      }

      String securityToken = securityInformation.getToken();

      if (securityToken == null) {
         if (anonymousAuthenticationToken != null) {
            // logger.info("Switching to anonymous authentication for " + securityInformation.get);
            LOGGER.info("Switching to anonymous authentication ... ??");
            authentication = anonymousAuthenticationToken;
         }
      }

      // Build authentication request token
      // Authentication verifyAuth = buildAuthentication(securityInformation, payload);
      SecurityAuditLogUtil.logSecurityAudit(Level.INFO, SECURITY_AUDIT_LOGS.AUTHN_ENTRY, authentication,
            resource);

      // get the original authentication token (reqd, if running as both server & client)
      Authentication orignalAuthentication = SecurityContextHolder.getContext().getAuthentication();

      try {
         // set the new authentication.
         SecurityContextHolder.getContext().setAuthentication(authentication);
         try {
            // invoke interceptor.
            authorizationInterceptor.beforeInvocation(resource);
         } catch (BaseSecurityException e) {
            SecurityAuditLogUtil.logSecurityAudit(Level.WARN, SECURITY_AUDIT_LOGS.AUTHN_EXIT, authentication,
                  resource);
            throw e;
         } catch (Exception e) {
            throw new AuthorizationException(e);
         }

         if (LOGGER.isInfoEnabled()) {
            LOGGER.info("Token " + SecurityContextHolder.getContext().getAuthentication()
                  + " , authorized for resource " + resource);
         }
      } finally {
         // reset the original authentication token.
         SecurityContextHolder.getContext().setAuthentication(orignalAuthentication);
      }
      if (LOGGER.isDebugEnabled()) {
         LOGGER.debug(className + "::authorize,  operation name = " + resource);
      }
   }
}
