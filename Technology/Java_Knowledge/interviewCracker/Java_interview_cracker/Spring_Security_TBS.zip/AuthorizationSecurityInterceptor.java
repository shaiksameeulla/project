package com.swacorp.tbs.security.providers;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.access.SecurityMetadataSource;
import org.springframework.security.access.intercept.InterceptorStatusToken;
import org.springframework.security.core.context.SecurityContextHolder;

import com.swacorp.tbs.security.exceptions.BaseSecurityException;
import com.swacorp.tbs.security.util.SecurityAuditLogUtil;
import com.swacorp.tbs.security.util.SecurityAuditLogUtil.SECURITY_AUDIT_LOGS;

/**
 * Class which intercepts all service invocations to check to see if the user is
 * authorized for access.
 * 
 * @author x14280
 * 
 */

public class AuthorizationSecurityInterceptor
		extends
		org.springframework.security.access.intercept.AbstractSecurityInterceptor {
	private SecurityMetadataSource securityMetadataSource;
	private static final Logger LOGGER = Logger
			.getLogger(AuthorizationSecurityInterceptor.class);

	@Override
	public Class<?> getSecureObjectClass() {
		return String.class;
	}

	/**
	 * method to get the security metdadata source.
	 * 
	 * @return SecurityMetadataSource the object that contains the
	 *         ConfigAttributeDefinition that applies to a given secure object
	 *         invocation
	 */
	@Override
	public SecurityMetadataSource obtainSecurityMetadataSource() {
		return this.securityMetadataSource;
	}

	/**
	 * Setter for the object definition source.
	 * 
	 * @param newSource
	 *            the security metadata source
	 */

	public void setSecurityMetadataSource(final SecurityMetadataSource newSource) {
		this.securityMetadataSource = newSource;
	}

	/**
	 * Method that gets invoked before the intercepter.
	 * 
	 * @param object
	 *            class contains any details
	 * @throws FWSecurityException
	 *             wrapping IllegalArgumentException FWSecurityException for
	 *             authentication failures SecurityTokenNotFoundException
	 *             exception if the token based authentication fails. other
	 *             Spring runtime exceptions (e.g.,
	 *             org.springframework.security.AccessDeniedException)
	 * @return InterceptorStatusToken class that reflects the status of the
	 *         security interception
	 */

	@Override
	public InterceptorStatusToken beforeInvocation(final Object object) {
		try {
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug(this.getClass().getSimpleName()
						+ ".beforeInvocation: " + object);
			}
			InterceptorStatusToken token = super.beforeInvocation(object);
			SecurityAuditLogUtil.logSecurityAudit(Level.INFO,
					SECURITY_AUDIT_LOGS.AUTHZ_EXIT, SecurityContextHolder
							.getContext().getAuthentication(), object
							.toString());
			return token;
		} catch (IllegalArgumentException ex) {
			throw new com.swacorp.tbs.security.exceptions.BaseSecurityException(
					"Authorization Failure (is server 'authDefinitions' bean misconfigured?)",
					ex);
		} catch (BaseSecurityException ex) {
			SecurityAuditLogUtil.logSecurityAudit(Level.WARN,
					SECURITY_AUDIT_LOGS.AUTHZ_EXIT, SecurityContextHolder
							.getContext().getAuthentication(), object
							.toString());
			throw ex;
		} catch (AccessDeniedException ex) {
			SecurityAuditLogUtil.logSecurityAudit(Level.WARN,
					SECURITY_AUDIT_LOGS.AUTHZ_EXIT, SecurityContextHolder
							.getContext().getAuthentication(), object
							.toString());
			throw ex;
		}
	}

	/**
	 * This is the way to call the AbstractSecurityInterceptor class after the
	 * secure object invocation has been complete.
	 * 
	 * @param token
	 *            as returned by the beforeInvocation(Object) method
	 * @param returnedObject
	 *            any object returned from the secure object invocation (may be
	 *            null)
	 * @return Object the object that the secure object invocation should
	 *         ultimately return to its caller
	 */

	@Override
	public Object afterInvocation(final InterceptorStatusToken token,
			final Object returnedObject) {
		return super.afterInvocation(token, returnedObject);
	}
}
