

package com.jcg.examples.repository;

import java.util.Collection;

import org.springframework.data.gemfire.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.jcg.examples.bean.RecordBean;

/**
 * @author Chandan Singh
 *
 */
@Repository
public interface RecordRepository extends CrudRepository<RecordBean, Integer> {

	RecordBean findByRecordId(String recordId);
	
	@Query("SELECT * FROM /record")  
  Collection<RecordBean> myFindAll();  
	
}